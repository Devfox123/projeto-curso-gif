package br.edu.senai.entidade;

public class PessoaFisica extends Pessoa {
	
	private String CPF;
	private String RG;
	
	
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public String getRG() {
		return RG;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	
	

}
