package br.edu.senai.entidade;

public class Pessoa {
	
	private int Idade;
	private String Endereco;
	private String Telefone;
	
	
	public int getIdade() {
		return Idade;
	}
	public void setIdade(int idade) {
		Idade = idade;
	}
	public String getEndereco() {
		return Endereco;
	}
	public void setEndereco(String endereco) {
		Endereco = endereco;
	}
	public String getTelefone() {
		return Telefone;
	}
	public void setTelefone(String telefone) {
		Telefone = telefone;
	}
	
	
	
	
	
	
	
	
	

}
